# StaySpace
StaySpace is a web app revolutionizing how students find accommodations. It tailors suggestions to their preferences—budget, amenities, and proximity.
